Exness EURUSDm M15 Bid/Ask derived OHLC, 2026-01-01 through 2026-11-09 UTC. Raw tick data provenance in pilot_results. Research-only; NOT V6.9d; no verified profitability.
