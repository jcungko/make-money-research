EURUSDm Exness indicative tick-derived candles for 2026-01-01 to 2026-11-09 UTC.
M5, M15, H1, with bid and ask OHLC; spread pips and tick count.
Source URLs, SHA256 hashes, supplemental March data, and limitations are documented in manifest.json.
November 10 daily ZIP was incomplete and excluded.
